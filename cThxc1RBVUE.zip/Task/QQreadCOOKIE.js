//独立COOKIE文件     ck在``里面填写，多账号换行
let QQreadurlVal = ``




let QQreadurlcookie = {

    QQreadurlVal: QQreadurlVal,

}

module.exports = QQreadurlcookie
