//独立COOKIE文件     ck在``里面填写，多账号换行

let bububaotokenVal = ``



let bububaocookie = {
    bububaotokenVal: bububaotokenVal,

}

module.exports = bububaocookie