

//独立COOKIE文件     ck在``里面填写，多账号换行
let xiaoleurlVal= ``
let xiaoleheaderVal= ``



let xiaolecookie = {
  xiaoleurlVal: xiaoleurlVal,	
  xiaoleheaderVal: xiaoleheaderVal,  

}

module.exports =  xiaolecookie
  


