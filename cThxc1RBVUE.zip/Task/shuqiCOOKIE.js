/* ziye
独立COOKIE文件
github地址 https://github.com/6Svip120apk69
TG频道地址  https://t.me/ziyescript
TG交流群   https://t.me/joinchat/AAAAAE7XHm-q1-7Np-tF3g
boxjs链接  https://raw.githubusercontent.com/6Svip120apk69/gitee_q8qsTAUA_cThxc1RBVUE/main/Task/ziye.boxjs.json

转载请备注个名字，谢谢

方式一
在boxjs里选择复制会话 粘贴至cookie1处


方式二
在boxjs里选择复制数据 粘贴至cookie2处



方式三
把每一个ck在分别``里面填写，多账号换行 

*/

modulees = 1 //1 选择方式一 2 选择方式二 3 选择方式三





//方式一
let cookie1 = {}



//方式二
let cookie2 = {}





//方式三
let shuqiuserurlVal = ``
let shuqisyurlVal = ``
let shuqisybodyVal = ``
let shuqispbodyVal = ``
let shuqiscbodyVal = ``
let shuqiydbodyVal = ``
let shuqiqdbodyVal = ``
let shuqirwbodyVal = ``
let shuqifxbodyVal = ``
let shuqisprwurlVal = ``
let shuqijlbodyVal = ``
let shuqisqjlbodyVal = ``
let shuqicjyurlVal = ``
let shuqicjcsbodyVal = ``
let shuqicjbodyVal = ``

let shuqijsspbodyVal = ``
let shuqijsydurlVal = ``
let shuqijsydbodyVal = ``
let shuqijsqdbodyVal = ``
let shuqijsqdspyurlVal = ``
let shuqijsqdspbodyVal = ``
let shuqijsrwbodyVal = ``
let shuqijsfxbodyVal = ``
let shuqijsbookurlVal = ``
let shuqijsbookbodyVal = ``
let shuqijssprwurlVal = ``






let cookie3 = {
    shuqiuserurlVal: shuqiuserurlVal,
    shuqisyurlVal: shuqisyurlVal,
    shuqisybodyVal: shuqisybodyVal,
    shuqispbodyVal: shuqispbodyVal,
    shuqiscbodyVal: shuqiscbodyVal,
    shuqiydbodyVal: shuqiydbodyVal,
    shuqiqdbodyVal: shuqiqdbodyVal,
    shuqirwbodyVal: shuqirwbodyVal,
    shuqifxbodyVal: shuqifxbodyVal,
    shuqisprwurlVal: shuqisprwurlVal,
    shuqijlbodyVal: shuqijlbodyVal,
    shuqisqjlbodyVal: shuqisqjlbodyVal,
    shuqicjyurlVal: shuqicjyurlVal,
    shuqicjcsbodyVal: shuqicjcsbodyVal,
    shuqicjbodyVal: shuqicjbodyVal,

    shuqijsspbodyVal: shuqijsspbodyVal,
    shuqijsydurlVal: shuqijsydurlVal,
    shuqijsydbodyVal: shuqijsydbodyVal,
    shuqijsqdbodyVal: shuqijsqdbodyVal,
    shuqijsqdspyurlVal: shuqijsqdspyurlVal,
    shuqijsqdspbodyVal: shuqijsqdspbodyVal,
    shuqijsrwbodyVal: shuqijsrwbodyVal,
    shuqijsfxbodyVal: shuqijsfxbodyVal,
    shuqijsbookurlVal: shuqijsbookurlVal,
    shuqijsbookbodyVal: shuqijsbookbodyVal,
    shuqijssprwurlVal: shuqijssprwurlVal

}






if (modulees == 1) {
    module.exports = cookie1
}

if (modulees == 2) {
    module.exports = cookie2
}


if (modulees == 3) {
    module.exports = cookie3
}